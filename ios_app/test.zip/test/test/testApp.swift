//
//  testApp.swift
//  test
//
//  Created by Kshitij Trivedi on 13/04/23.
//

import SwiftUI

@main
struct testApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
